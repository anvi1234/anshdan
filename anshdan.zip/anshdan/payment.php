<?php
require_once("config.php");
?>
<html>


<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Payment Gateway</title>
</head>
<body>
<form action="charge.php" method="POST"> 
<script    src="https://checkout.razorpay.com/v1/checkout.js"   
 data-key=<?php echo $api_key_id ?>    data-amount="50000"    data-currency="INR"        data-buttontext="Pay with Razorpay"    data-name="Anshdan"    data-description="Money transaction"    data-image="https://example.com/your_logo.jpg"    data-prefill.name="Ravi Kumar Chaudhary"    data-prefill.email="anshdan02@gmail.com"    data-prefill.contact="6387532966"    data-theme.color="#F37254"></script><input type="hidden" custom="Hidden Element" name="hidden"></form>
</body>
</html>