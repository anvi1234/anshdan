// $(document).ready(function(){
//     var app=Sammy("#content" ,function(){
//         this.get("/",function(context){
//            $("#content").load("main.html");
//         })
//          this.get("/gallery",function(context){
//          this.load("gallery.html");
//         })
//     })

//     app.run("/")

// })



// $(document).ready(function(){
//     var app = $.sammy(function() {
//         this.get("/",function(context){
//          window.load="http://anshdan.epizy.com/index.html";
//         });
//         this.get("/gallery",function(){
//            window.load="http://anshdan.epizy.com/gallery.html";
//         })
//     })

//     app.run("/")

// })

;(function($) {
  var app = new Sammy.Application(function() {
    with(this) {
      get('#/', function() { with(this) {
           url = encodeURIComponent("index.html");
        url = url.replace(/#/g, '%23');
       window.load=url
      }});

      get('#/gallery', function() { with(this) {
        url = encodeURIComponent("gallery.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
       get('#/getinvolved/volunteer', function() { with(this) {
        url = encodeURIComponent("volunteer.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
       get('#/getinvolved/internship', function() { with(this) {
        url = encodeURIComponent("internship.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
      get('#/whoweare/ourteamandallies', function() { with(this) {
        url = encodeURIComponent("team.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
       get('#/whoweare/about', function() { with(this) {
        url = encodeURIComponent("about.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
       get('#/whatwedo/ourproject', function() { with(this) {
        url = encodeURIComponent("project.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
       get('#/whatwedo/emergencies', function() { with(this) {
        url = encodeURIComponent("emergency.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
       get('#/academic', function() { with(this) {
        url = encodeURIComponent("academic.php");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
      get('#/whoweare/areaofwork', function() { with(this) {
        url = encodeURIComponent("areaofwork.html");
        url = url.replace(/#/g, '%23');
        
        window.location.replace(url)
      }});
      
    }
  });
  $(function() {
    app.run('#/')
  });
})(jQuery);