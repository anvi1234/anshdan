<?php
$conn = mysqli_connect("sql209.epizy.com", "epiz_26194030", "o4FTvcWCjP", "epiz_26194030_anshdan");
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
else{
$sql = "SELECT * FROM course_structure";
    $result = mysqli_query($conn,$sql);
    $i=1;
    if(mysqli_num_rows($result) > 0){
    }else{
        $msg = "No Record found";
    }
}



?>























<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Anshdan Welfare Foundation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link href="https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Overpass:300,400,400i,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="style.css">


    <style>
        body {
  font-family: Arial, sans-serif;
  font-size: 14px;
  line-height: 20px;
  color: #333333;
}

table, th, td {
  border: solid 1px #000;
  padding: 10px;
}

table {
    border-collapse:collapse;
    caption-side:bottom;
}


        </style>
  </head>
  <body>
    
 
     
<div id="nav">
</div>
   
    <!-- END nav -->
    
    <div class="hero-wrap" style="background-image: url('images/academic.jpg');max-height:400px" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate text-center"   data-scrollax=" properties: { translateY: '70%' }">
             
            <h1 class="mb-3 bread"  style="font-family:Arial, Helvetica, sans-serif;text-shadow: 2px 2px black;" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">ACADEMICS</h1>
          </div>
        </div>
      </div>
    </div>
    <div class="bottomnav" style="background-color:grey;text-align:left;color:blue">
 <p class="breadcrumbs" style="color:#87CEEB" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.html" style="color:#87CEEB">Home</a></span>>> <span style="color:#87CEEB">Academics</span></p>
</div>

    
    <section class="ftco-section">
    	<div class="container">
    		<div class="row d-flex">
    			<div class="col-md-6  offset-md-3 d-flex ftco-animate">
    				<table>
	
	<thead>
      <tr>
        <th>So. No.</th>
        <th>Course</th>
        
      </tr>
  </thead>
  <tbody>
       <?php
            $i=0;
                while($row = mysqli_fetch_assoc($result)){
                    ?>
      <tr>
        <td> <?php echo $row['course_id']; ?></td>
        <td><?php echo $row['course']; ?></td>
        
      </tr>
     
       
           <?php
	$i++;
	}
	?>
  </tbody>
 
</table>
    			</div>
    		
    		</div>
    	</div>
    </section>


    <section style="margin-bottom:10px">
    <div class="row">
    <div class="col-md-6  offset-md-3">
    <button style="font-size:100px;color:white;background-color:#fd7e14;height:100%;width:75%;border:none">
    <div class="row">
    <div class="col-sm-4">
    <i class="fa fa-cloud-download"></i>
    </div>
    <div class="col-sm-8">
    <h5 style="color:white">Download</h5><h3 style="color:white">PROSPECTUS</h3><h6 style="color:white">Download our all program prospectus...</h6>
    
    </div>
    
    </div>
    </div>
    </div>
    </section>

    
		

    <footer class="ftco-footer ftco-section img">
    	<div class="overlay"></div>
     
          
             
         
          
        <div class="row">
          <div class="col-md-12 text-center">

            <p>
 All rights reserved | This website is designed and  developed by  <i class="icon-heart" aria-hidden="true"></i> by <a href="http://www.yoursighthub.xyz/" target="_blank">Your Sight Hub</a>
 </p>
          </div>
        
      </div>
    </footer>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
   <script src="js/sammy.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
   <script src="index.js"></script>
    <script src="route.js"></script>
    
  </body>
</html>