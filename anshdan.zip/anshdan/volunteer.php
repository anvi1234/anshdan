<?php
// $servername = "sql209.epizy.com";
// $username = "epiz_26194030";
// $password = "o4FTvcWCjP";
// $dbname = "epiz_26194030_anshdan";

// Create connection
$conn = mysqli_connect("sql209.epizy.com", "epiz_26194030", "o4FTvcWCjP", "epiz_26194030_anshdan");
// $conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
// if ($conn->connect_error) {
//   die("Connection failed: " . $conn->connect_error);
// }
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

	$fullname = mysqli_real_escape_string($conn, $_REQUEST['fullname']);
    	$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
        	$age = mysqli_real_escape_string($conn, $_REQUEST['age']);
            $gender = mysqli_real_escape_string($conn, $_REQUEST['gender']);
             $phone = mysqli_real_escape_string($conn, $_REQUEST['phone']);
               $address = mysqli_real_escape_string($conn, $_REQUEST['address']);
                $city = mysqli_real_escape_string($conn, $_REQUEST['city']);
                  $profession = mysqli_real_escape_string($conn, $_REQUEST['profession']);
                     $contributiontime = mysqli_real_escape_string($conn, $_REQUEST['contributiontime']);
                        $skill = mysqli_real_escape_string($conn, $_REQUEST['skill']);
                         $story = mysqli_real_escape_string($conn, $_REQUEST['story']);
 

	
	 $sql = "INSERT INTO vounteer (fullName,email,age,gender,phone,address,city,profession,contributiontime,skill,story)
	 VALUES ('$fullname', '$email' ,'$gender', '$age','$phone','$address','$city','$profession','$contributiontime','$skill','$story')";


if ($conn->query($sql) === TRUE) {
  echo "Registeration done successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
