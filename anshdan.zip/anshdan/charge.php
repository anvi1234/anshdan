<?php
if($_POST){
    $razorpay_payment_id=$_POST('razorpay_payment_id');
    echo "RazorPay success id:". $razorpay_payment_id;
}
?>