$(function() {
    $("#nav").load("nav/nav.html");
});