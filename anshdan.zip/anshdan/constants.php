<?php 
// credential
define('RAZOR_KEY_ID', 'rzp_test_Ae1ImAEQJHEo38');

 
?>	