<?php
// $servername = "sql209.epizy.com";
// $username = "epiz_26194030";
// $password = "o4FTvcWCjP";
// $dbname = "epiz_26194030_anshdan";

// Create connection
$conn = mysqli_connect("sql209.epizy.com", "epiz_26194030", "o4FTvcWCjP", "epiz_26194030_anshdan");
// $conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
// if ($conn->connect_error) {
//   die("Connection failed: " . $conn->connect_error);
// }
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


$email = $_POST["email"];
$to = "anveshikagbu@gmail.com";
$subject = "New Email Address for Mailing List";
$headers = "From: $email\n";
$message = "A visitor to your site has sent the following email address to be added to your mailing list.\n

Email Address: $email";
$user = "$email";
$usersubject = "Thank You";
$userheaders = "From: you@youremailaddress.com\n";
$usermessage = "Thank you for subscribing to our mailing list.";
mail($to,$subject,$message,$headers);
mail($user,$usersubject,$usermessage,$userheaders);

	$fullname = mysqli_real_escape_string($conn, $_REQUEST['fullname']);
    	$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
        	$rawdate = htmlentities($_POST['whenustartdate']);
            $whenustartdate = date('Y-m-d', strtotime($rawdate));
           
             $phone = mysqli_real_escape_string($conn, $_REQUEST['phone']);
               
                $city = mysqli_real_escape_string($conn, $_REQUEST['city']);
                  $profession = mysqli_real_escape_string($conn, $_REQUEST['profession']);
                     $contributiontime = mysqli_real_escape_string($conn, $_REQUEST['contributiontime']);
                        $skill = mysqli_real_escape_string($conn, $_REQUEST['skill']);
                         $story = mysqli_real_escape_string($conn, $_REQUEST['story']);
                        
                         $resume = rand(1000,10000)."-".$_FILES["resume"]["name"];
                         $tname = $_FILES["resume"]["tmp_name"];
                         $uploads_dir = 'images';
                          #TO move the uploaded file to specific location
    move_uploaded_file($tname, $uploads_dir.'/'.$resume);
 
 

	
	 $sql = "INSERT INTO internship (fullname,email,whenustartdate,phone,city,profession,contributiontime,skill,story,resume)
	 VALUES ('$fullname', '$email' ,'$whenustartdate','$phone','$city','$profession','$contributiontime','$skill','$story','$resume')";


if ($conn->query($sql) === TRUE) {
  echo "Registeration done successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}






$conn->close();
?>
