<?php

$conn = mysqli_connect("sql209.epizy.com", "epiz_26194030", "o4FTvcWCjP", "epiz_26194030_anshdan");
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
if(isset($_POST['submit'])){

$course=mysqli_real_escape_string($conn, $_REQUEST['course']);;

$sql = "INSERT INTO course_structure (course)
	 VALUES ('$course')";
}


if ($conn->query($sql) === TRUE) {
  echo "Registeration done successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();





?>

